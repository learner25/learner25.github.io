
<form action="login.php" method="POST">
 <input type="hidden" value="1" name="status"/>
  <input type="text" name="id" value="" id="name1"/>
  <input type="password" name="pass" value="" />
  <input type="submit" />
  
  
   
</form>
or,<br>
<br>
<a href="reg.php">register</a>