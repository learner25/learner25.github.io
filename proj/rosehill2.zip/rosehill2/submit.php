<?php 
$babu = $_POST['lol']  ;
{
echo "welcome $babu";
}

 ?>