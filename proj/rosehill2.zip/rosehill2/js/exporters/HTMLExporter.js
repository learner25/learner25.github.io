/**
 * @author mrdoob / http://mrdoob.com/
 */

THREE.HTMLExporter = function () {};

THREE.HTMLExporter.prototype = {

	constructor: THREE.HTMLExporter,

	parse: function ( scene ) {

		return output;

	}

}
